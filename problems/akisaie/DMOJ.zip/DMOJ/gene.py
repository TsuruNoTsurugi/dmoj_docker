import os

def prime(n):
    a = []
    while(n%57==0):
        a.append(57)
        n//=57
    while(n%2==0):
        a.append(2)
        n//=2
    p=3
    while p*p<=n:
        if(n%p==0):
            a.append(p)
            n//=p
        else:
            p+=2
    if n != 1:
        a.append(n)
    return sorted(a)

path="/var/www/html/kougakubu/htdocs/problems/E/input"
path2="/var/www/html/kougakubu/htdocs/problems/E/output"
for filename in os.listdir(path):
   with open(os.path.join(path, filename), 'r') as f:
       num = int(f.read())
       li=prime(num)
       fi = open(os.path.join(path2,filename),"w")
       fi.write(" ".join(map(str,li))+"\n")
       fi.close()


#print(prime(int(input())))
